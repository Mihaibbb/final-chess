CREATE TABLE details (
    name varchar(128) not null,
    date date not null,
    _id varchar(25) not null
);